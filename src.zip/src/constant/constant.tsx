export const serverPath = 'http://localhost:3001/api/v1/';

export const login = 'auth/login';