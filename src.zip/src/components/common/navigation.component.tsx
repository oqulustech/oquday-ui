import { Row, Col } from "react-bootstrap"
export default function NavHeader() {
    return (
        <Row>
            <Col className="col-6"> <h2> This is Navigation Part</h2 ></Col>
            <Col className="col-6"> <h2> This is Navigation Part</h2 ></Col>
        </Row>
    )
}