export default function SubmitButton() {
    return (
        <h1> Button</h1>
    )
}