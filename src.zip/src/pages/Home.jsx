import React from "react";

const Home = () => {
  return <div>Home this is Home page </div>;
};

export default Home;
