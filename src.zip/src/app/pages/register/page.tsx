import Image from "next/image";
import styles from "./page.module.css";
import RegisterComponent from '../../../components/common/register'
export default function LoginPage() {

    return (
        <RegisterComponent />
    );
}
